## General info
This folder contains the code for paper "Subsampling Sparse Graphons Under Minimal Assumptions". 

##File Descriptions
network_simulate.R  --- R source file for simulating graphons

network_resampling.R ---  R source file for resampling graphons.  Includes functions for subsampling, jackknife bias corrections, empirical graphon bootstrap of Green and Shalizi and the latent space bootstrap of Levin and Levina.  