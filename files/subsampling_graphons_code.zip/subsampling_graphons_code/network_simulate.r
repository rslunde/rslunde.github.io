### Functions to simulate from graphon models, latent space models, and stochastic
# block models.  RCpp is used to speed up simulation from a Bernoulli matrix.
# For graphons and latent space models, the function is passed as a string.
# SBMs can be simulated faster and have their own simulation function.

# If return return_P_mat = TRUE, then the probability (mean) matrix
# is also returned.  

library(methods)
library(Rcpp)
library(RcppArmadillo)

# Set object classes for SBM, Graphon, LSM
setClass("graphon",representation(w_function="character",nu_seq = "function"))
setClass("sbm",representation(B_mat="matrix",pi_vec="numeric",nu_seq = "function"))
setClass("lsm",representation(kernel_function="character",latent_dist ="character",nu_seq = "function"))

create_simulation_function =  function(x,return_P_mat =FALSE) UseMethod("create_simulation_function")

create_simulation_function.sbm = function(sbm,return_P_mat =FALSE){
  
  cppFunction( 'arma::mat my_function_1( int n, double nu, NumericMatrix B_mat,
               NumericVector pi_vec ) {
               arma::mat A_mat(n,n,arma::fill::zeros);
               int num_class = pi_vec.size();
               IntegerVector my_classes = seq_len(num_class);
               
               IntegerVector class_assignment = Rcpp::sample(my_classes,n,true,pi_vec);
               
               for (int ii = 0; ii < n; ii++)
               {
               for(int jj = ii+1; jj < n; jj++) 
               {
               int x_temp = class_assignment[ii]-1;
               int y_temp = class_assignment[jj]-1;
               
               double P_temp = nu * B_mat(x_temp, y_temp);
               A_mat(ii,jj) = R::rbinom(1,P_temp);
               }
               }
               A_mat = arma::symmatu(A_mat);
               return(A_mat);
               }
               ',depends = "RcppArmadillo")
  cppFunction( 'List my_function_2( int n, double nu, NumericMatrix B_mat,
               NumericVector pi_vec ) {
               arma::mat A_mat(n,n,arma::fill::zeros);
               arma::mat P_mat(n,n,arma::fill::zeros);
               int num_class = pi_vec.size();
               IntegerVector my_classes = seq_len(num_class);
               
               IntegerVector class_assignment = Rcpp::sample(my_classes,n,true,pi_vec);
               
               for (int ii = 0; ii < n; ii++)
               {
               for(int jj = ii+1; jj < n; jj++) 
               {
               int x_temp = class_assignment[ii]-1;
               int y_temp = class_assignment[jj]-1;
               
               double P_temp = nu * B_mat(x_temp, y_temp);
               P_mat(ii,jj) = P_temp;
               A_mat(ii,jj) = R::rbinom(1,P_temp);
               }
               }
               A_mat = arma::symmatu(A_mat);
               P_mat = arma::symmatu(P_mat);
               List ret;
               ret["A_mat"] = A_mat;
               ret["P_mat"] = P_mat;
               return ret;
               }
               ',depends = "RcppArmadillo")
  
  if(return_P_mat){  
    output = function(n) {
      return( my_function_2(n=n,nu=sbm@nu_seq(n),B_mat = sbm@B_mat, pi_vec = sbm@pi_vec))
    }
    return(output)
  }
  else{
    output = function(n) {
      return( my_function_1(n=n,nu=sbm@nu_seq(n),B_mat = sbm@B_mat, pi_vec = sbm@pi_vec))
    }
    return(output)
    
  }
}


create_simulation_function.graphon = function(graphon,return_P_mat =FALSE) {
  
  cppFunction( 'arma::mat my_function_1( int n, double nu) {
               arma::mat A_mat(n,n,arma::fill::zeros);
               NumericVector latent_positions = runif(n,0,1);
               for (int ii = 0; ii < n; ii++)
               {
               for(int jj = ii+1; jj< n; jj++) 
               {
               double P_temp = nu * w_function(latent_positions[ii],latent_positions[jj]);
               A_mat(ii,jj) =  R::rbinom(1,P_temp);
               }
               }
               A_mat = arma::symmatu(A_mat);
               return(A_mat);
}
',depends = "RcppArmadillo", includes = graphon@w_function)
  
  cppFunction( 'List my_function_2( int n, double nu) {
               arma::mat A_mat(n,n,arma::fill::zeros);
               arma::mat P_mat(n,n,arma::fill::zeros);
               NumericVector latent_positions = runif(n,0,1);
               for (int ii = 0; ii < n; ii++)
               {
               for(int jj = ii+1; jj< n; jj++) 
               {
               double P_temp = nu * w_function(latent_positions[ii],latent_positions[jj]);
               A_mat(ii,jj) =  R::rbinom(1,P_temp);
               P_mat(ii,jj) = P_temp;
               }
               }
               A_mat = arma::symmatu(A_mat);
               P_mat = arma::symmatu(P_mat);
               List ret;
               ret["A_mat"] = A_mat;
               ret["P_mat"] = P_mat;
               return ret;
}
',depends = "RcppArmadillo", includes = graphon@w_function) 
  
   
  if(return_P_mat){  
    output = function(n) {
      return( my_function_2(n=n,nu=graphon@nu_seq(n)))
    }
    return(output)
  }
  else{
    output = function(n) {
      return( my_function_1(n=n,nu=graphon@nu_seq(n)))
      
      return(output)
    }
  }
}

create_simulation_function.lsm = function(lsm,return_P_mat =FALSE) {
  
  cppFunction( paste0('arma::mat my_function_1( int n, double nu) {
                      arma::mat A_mat(n,n,arma::fill::zeros);
                      NumericVector latent_positions = ',lsm@latent_dist[1], 'n', 
                      lsm@latent_dist[2], ';
                      for (int ii = 0; ii < n; ii++)
                      {
                      for(int jj = ii+1; jj< n; jj++) 
                      {
                      double P_temp = nu * kernel_function(latent_positions[ii],latent_positions[jj]);
                      A_mat(ii,jj) =R::rbinom(1,P_temp);
                      
                      }
                      }
                      A_mat = arma::symmatu(A_mat);
                      return(A_mat); 
}
'),depends = "RcppArmadillo", includes = lsm@kernel_function)
  
  cppFunction( paste0('List my_function_2( int n, double nu) {
                      arma::mat A_mat(n,n,arma::fill::zeros);
                      arma::mat P_mat(n,n,arma::fill::zeros);  
                      
                      NumericVector latent_positions = ',lsm@latent_dist[1], 'n', 
                      lsm@latent_dist[2], ';
                      for (int ii = 0; ii < n; ii++)
                      {
                      for(int jj = ii+1; jj< n; jj++) 
                      {
                      double P_temp = nu * kernel_function(latent_positions[ii],latent_positions[jj]);
                      A_mat(ii,jj) =R::rbinom(1,P_temp);
                      P_mat(ii,jj) = P_temp;
                      }
                      }
                      A_mat = arma::symmatu(A_mat);   
                      P_mat = arma::symmatu(P_mat);
                      List ret;
                      ret["A_mat"] = A_mat;
                      ret["P_mat"] = P_mat;
                      return ret;
                      }
                      '),depends = "RcppArmadillo", includes = lsm@kernel_function)
  
  if(return_P_mat){  
    output = function(n) {
      return(my_function_2(n=n,nu=lsm@nu_seq(n)))
    }
    return(output)
  }
  else{
    output = function(n) {
      return(my_function_1(n=n,nu=lsm@nu_seq(n)))
      
      return(output)
    }
  }
  }

# Graphon Function Repository, selected from Chan and Airoldi (2014)

#Comments: rank = 2 
graphon.3 = 'double w_function(double u, double v) {
return(0.25*(pow(u,2)+pow(v,2)+pow(u,0.5)+pow(v,0.5)));
}'

# Comments: rank = 10
graphon.5 = 'double w_function(double u, double v) {
return(1/(1+exp(-10*(pow(u,2)+pow(v,2)))));
}'

#Comments: eigenvalues/functions of graphon calculable following Xu (2017), high rank.  
graphon.6 = 'double w_function( double u, double v) {
return(std::abs(u-v));
}'

#Comments: high rank
graphon.7 = ' double w_function(double u, double v) {
return(1/(1+exp(-1*(pow(std::max(u,v),2) + pow(std::min(u,v),4)))));
}'
#Comments: high rank
graphon.10 =' double w_function(double u, double v) {
return(log(1+0.5*std::max(u,v)));
}'

graphon.prod = 'double w_function(double u, double v) {
return(u*v);
}'

###########################################
# SBM Repository

# SBM object stuided in Lei
B_mat_3= matrix(c(0.25,0.5,0.25,0.5,0.25,0.25,0.25,0.25,1/6),nrow=3)
pi_vec_3=c(0.3,0.3,0.4)

###########################################
# Gaussian Latent Space Model
my_gaussian_lsm_kernel = ' double kernel_function(double u, double v) {
return(exp(-25*(pow(u-v,2))));
}'



